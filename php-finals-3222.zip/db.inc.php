<?php
		$dbServername = "localhost";	//change if on online server
		$dbUsername = "root";		//change if on online server
		$dbPassword = "";		//change if on online server
		$dbName = "phpcontacts";	//name of data base
		$conn = mysqli_connect($dbServername, $dbUsername, $dbPassword, $dbName);

?>